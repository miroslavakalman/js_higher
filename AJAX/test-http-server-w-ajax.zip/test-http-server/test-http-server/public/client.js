// let div    = document.querySelector('div');
// let button = document.querySelector('button');
// button.addEventListener('click', function() {
// 	fetch('/ajax.html').then(
// 		response => {
// 			return response.text();
// 		}
// 	).then(
// 		text => {
// 			div.innerHTML = text;
// 		}
// 	);
// });
// button.addEventListener('click', function() {
// 	let promise = fetch('/ajax.html')
// 	.then(
// 		response => {
// 			if (response.ok) {
// 				return response.text();
// 			} else {
// 				throw new Error('плохой статус ответа');
// 			}
// 		},
// 	).then(
// 		text => {
// 			console.log(text);
// 		}
// 	).catch(
// 		error => {
// 			console.log(error);
// 		}
// 	);
// });
// button.addEventListener('click', function() {
// 	fetch('/ajax.html').then(response => {
// 		console.log(response.headers.get('Content-Length'));
// 	});
// });

// let fetchButton = document.getElementById('fetchButton');
// let myList = document.getElementById('myList');

// fetchButton.addEventListener('click', function() {
//     fetch('data.json') 
//         .then(response => response.json())
//         .then(data => {
//             myList.innerHTML = '';

//             data.forEach(item => {
//                 let li = document.createElement('li');
//                 li.textContent = item.item;
//                 myList.appendChild(li);
//             });
//         })
//         .catch(error => console.error('Ошибка при загрузке данных:', error));
// });
// let calculateButton = document.getElementById('calculateButton');
// let resultDiv = document.getElementById('resultDiv');

// calculateButton.addEventListener('click', function() {
//     let num1 = 5; 
//     let num2 = 7; 

//     fetch(`/handler/?num1=${num1}&num2=${num2}`)
//         .then(response => response.text())
//         .then(result => {
//             resultDiv.textContent = `Сумма: ${result}`;
//         })
//         .catch(error => console.error('Ошибка при запросе:', error));
// });

// let calculateButton = document.getElementById('calculateButton');
// let num1Input = document.getElementById('num1Input');
// let num2Input = document.getElementById('num2Input');
// let num3Input = document.getElementById('num3Input');
// let resultDiv = document.getElementById('resultDiv');

// calculateButton.addEventListener('click', function() {
//     let num1 = num1Input.value;
//     let num2 = num2Input.value;
//     let num3 = num3Input.value;

//     let searchParams = new URLSearchParams();
//     searchParams.set('num1', num1);
//     searchParams.set('num2', num2);
//     searchParams.set('num3', num3);

//     fetch('/handler/', {
//         method: 'POST',
//         body: searchParams
//     })
//     .then(response => response.text())
//     .then(result => {
//         resultDiv.textContent = `Сумма чисел: ${result}`;
//     })
//     .catch(error => console.error('Ошибка при запросе:', error));
// });

// button.addEventListener('click', async function() {
//     try {
//         let response = await fetch('/ajax.html');

//         if (!response.ok) {
//             throw new Error('плохой статус ответа');
//         }

//         let text = await response.text();
//         console.log(text);
//     } catch (error) {
//         console.log(error);
//     }
// });
