// const storedUsername = 'admin';  
// const storedPassword = 'admin123'; 
export default {
    // '/handler/': function(data) {
	// 	console.log(data); // выведется в консоль сервера
	// 	return 'form data received';
	// }

    // '/average/': function({get}) {
    //     const num1 = Number(get.num1);
    //     const num2 = Number(get.num2);
    //     const num3 = Number(get.num3);
    //     const num4 = Number(get.num4);
    //     const num5 = Number(get.num5);

    //     const average = (num1 + num2 + num3 + num4 + num5) / 5;

    //     return 'Среднее арифм.: ' + average;
    // }

    // '/userinfo/': function({get}) {
    //     const firstName = get.firstName;
    //     const lastName = get.lastName;
    //     const middleName = get.middleName;

    //     return firstName + ' ' + lastName + ' ' + middleName;
    // }

    // '/checkdate/': function({get}) {
    //     const dateInput = get.dateInput;

    //     const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

    //     if (dateRegex.test(dateInput)) {
    //         return 'дата: ' + dateInput;
    //     } else {
    //         return 'введите дату заново.';
    //     }
    // },

    // '/login/': function({post}) {
    //     const enteredUsername = post.username;
    //     const enteredPassword = post.password;

    //     if (enteredUsername === storedUsername && enteredPassword === storedPassword) {
    //         return 'Вход произведен';
    //     } else {
    //         return 'Повторите попытку.';
    //     }
    // }
}


