let form = document.getElementById('myForm');
let submitButton = document.getElementById('submitButton');

submitButton.addEventListener('click', function(event) {
    event.preventDefault(); // Предотвращаем действие по умолчанию (переход по ссылке)

    form.submit(); // Отправляем форму
});
