export default {
	port: '3001',
}