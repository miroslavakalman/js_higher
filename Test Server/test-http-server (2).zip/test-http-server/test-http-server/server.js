let arr = [1, 2, 3, 4, 5];
export default {
	// '/page1/': function() {
	// 	return 'hello world';
	// },
    // '/page2/': function() {
	// 	return 'hello world';
	// },
    // '/page3/': function() {
	// 	return 'hello world';
	// },

	'/array-elements/': function() {
		let html = '<div>';

		arr.forEach(element => {
			html += '<p>' + element + '</p>';
		});

		html += '</div>';

		return html;
	},
    '/handler/': function(data, resp) {
		resp.setHeader('Content-Type', 'text/plain');
		return '[1,2,3]';
	}
}


