export default {
	port: '3002',
}